import psycopg2
import user, car, station, driver, customer, trip

print(car.getAllCars())
