Asil cevap: main.asm + conway.asm
BONUS: mainDP.asm + conwayDP.asm

Akis diyagrami ve stack analizi: Odev3FlowchartStackAnalizi.pdf
( Stack analizinda +2 +4 +8 olarak ilerlenmis, kodda +6 duzeltmistir )